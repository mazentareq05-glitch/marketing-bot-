"""
بوت تليجرام لجمع ترندات التسويق وإرسالها أسبوعياً
=====================================================

النسخة دي بتغطي 4 أقسام:
1. تحديثات Meta Ads.
2. فيديوهات نجحت (فايرال) + تحليل ليه نجحت (من مقالات متخصصة).
3. ترندات التسويق العامة — معروضة كمقال مختصر بدل قايمة روابط.
4. تحديثات أي منصة سوشيال ميديا (Meta, TikTok, LinkedIn, X...).

كل المصادر عالمية (إنجليزية) مش مقصورة على مصر.

قبل التشغيل:
------------
1. ثبّت المكتبات المطلوبة:
   pip install feedparser python-telegram-bot pytrends requests schedule

2. التوكن والـ CHAT_ID متحطين خلاص تحت.

3. شغل السكريبت للتجربة:
   python marketing_trends_bot.py

ملحوظة مهمة عن بعض الفيدات:
----------------------------
بعض روابط RSS تحت اتحطت بناءً على المصادر المعروفة، لكن المواقع بتغيّر
روابطها من وقت للتاني. لو ظهرلك تحذير ⚠️ في التيرمينال بتاع مصدر معين،
معناه الرابط بايظ أو اتغيّر، وده مبيوقفش باقي البوت — بس ممكن تبعتلي
اسم المصدر وأدورلك على رابط بديل.
"""

import feedparser
import requests
import os
from datetime import datetime

# ============ الإعدادات ============
# التوكن والـ CHAT_ID بيتقروا من متغيرات بيئة محمية (GitHub Secrets)
# بدل ما يبقوا مكتوبين صريح هنا، عشان محدش يشوفهم لو الملف اتفتح لأي حد.
# القيمة اللي بعد os.environ.get هي قيمة احتياطية بس (للتجربة على جهازك لو حابب).
BOT_TOKEN = os.environ.get("BOT_TOKEN", "8999205770:AAEH3857YbT8FbZyxpIwlD4Ty_KSQsnlgxc")
CHAT_ID = os.environ.get("CHAT_ID", "1127852168")

# عدد المقالات اللي هتتجاب من كل مصدر في كل قسم
ARTICLES_PER_SOURCE = 2

# طول الملخص (الاقتباس) اللي هيتاخد من كل مقال عشان يتعرض كـ"مقال مختصر"
SUMMARY_LENGTH = 220

# ============ الأقسام والمصادر ============
# كل قسم عنده اسم وقايمة مصادر RSS خاصة بيه
CATEGORIES = {
    "📢 تحديثات Meta Ads": {
        "Meta Newsroom": "https://about.fb.com/news/feed/",
        "Search Engine Journal (PPC)": "https://www.searchenginejournal.com/category/pay-per-click/feed/",
        "AdWeek": "https://www.adweek.com/feed/",
    },
    "🎬 فيديوهات نجحت وليه": {
        "TubeFilter": "https://www.tubefilter.com/feed/",
        "Social Media Today": "https://www.socialmediatoday.com/feeds/news/",
    },
    "📈 ترندات التسويق العامة": {
        "Marketing Dive": "https://www.marketingdive.com/feeds/news/",
        "HubSpot Marketing Blog": "https://blog.hubspot.com/marketing/rss.xml",
        "Search Engine Journal": "https://www.searchenginejournal.com/feed/",
    },
    "📱 تحديثات المنصات (كل منصة)": {
        "Social Media Today (Platforms)": "https://www.socialmediatoday.com/feeds/news/",
        "Digiday": "https://digiday.com/feed/",
    },
}


# ============ دوال مساعدة ============

def clean_summary(raw_summary):
    """يشيل أي HTML tags من ملخص المقال ويقصره لطول مناسب لعرض 'مقال مختصر'."""
    import re
    text = re.sub("<[^<]+?>", "", raw_summary or "")
    text = text.strip()
    if len(text) > SUMMARY_LENGTH:
        text = text[:SUMMARY_LENGTH].rsplit(" ", 1)[0] + "..."
    return text


def fetch_category_items(feeds_dict):
    """يجمع أحدث المقالات (عنوان + ملخص + رابط) من مصادر قسم معين."""
    items = []
    for source_name, url in feeds_dict.items():
        try:
            feed = feedparser.parse(url)
            if feed.bozo and not feed.entries:
                print(f"⚠️ مصدر '{source_name}' فيه مشكلة أو الرابط بايظ، هيتم تخطيه.")
                continue
            entries = feed.entries[:ARTICLES_PER_SOURCE]
            for entry in entries:
                summary = clean_summary(entry.get("summary", ""))
                items.append({
                    "source": source_name,
                    "title": entry.get("title", "بدون عنوان"),
                    "summary": summary,
                    "link": entry.get("link", ""),
                })
        except Exception as e:
            print(f"⚠️ حصل خطأ في جلب {source_name}: {e}")
    return items


def fetch_google_trends():
    """يجيب كلمات ترند صاعدة عالمياً متعلقة بالتسويق (اختياري)."""
    try:
        from pytrends.request import TrendReq
        # بدون geo => نتايج عالمية مش مقصورة على دولة معينة
        pytrends = TrendReq(hl="en-US", tz=360)
        keywords = ["digital marketing", "social media marketing", "meta ads"]
        pytrends.build_payload(keywords, timeframe="now 7-d")
        related = pytrends.related_queries()
        trending_terms = []
        for kw in keywords:
            data = related.get(kw, {}).get("rising")
            if data is not None and not data.empty:
                trending_terms.extend(data["query"].head(3).tolist())
        return trending_terms
    except Exception as e:
        print(f"⚠️ حصل خطأ في جلب Google Trends: {e}")
        return []


# ============ تجهيز الرسالة (شكل مقال مختصر) ============

def build_message():
    today = datetime.now().strftime("%Y-%m-%d")
    message = f"📊 *ترندات التسويق الأسبوعية* — {today}\n"
    message += "_(مصادر عالمية)_\n"

    google_terms = fetch_google_trends()
    if google_terms:
        message += "\n🔥 *كلمات صاعدة على Google عالمياً:*\n"
        message += "، ".join(google_terms[:6]) + "\n"

    for category_name, feeds in CATEGORIES.items():
        items = fetch_category_items(feeds)
        if not items:
            continue
        message += f"\n\n━━━━━━━━━━━━━━\n{category_name}\n"
        for item in items:
            # شكل "مقال مختصر": عنوان بولد، وتحته فقرة ملخصة، وتحتها رابط المصدر الكامل
            message += f"\n*{item['title']}*\n"
            if item["summary"]:
                message += f"{item['summary']}\n"
            message += f"[اقرأ المزيد - {item['source']}]({item['link']})\n"

    return message


# ============ إرسال الرسالة على تليجرام ============

def send_telegram_message(text):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    # تليجرام بيحدد طول الرسالة بـ 4096 حرف، فلو الرسالة طويلة نقسمها
    max_len = 4000
    chunks = [text[i:i + max_len] for i in range(0, len(text), max_len)]
    for chunk in chunks:
        payload = {
            "chat_id": CHAT_ID,
            "text": chunk,
            "parse_mode": "Markdown",
            "disable_web_page_preview": True,
        }
        response = requests.post(url, data=payload)
        if response.status_code != 200:
            print(f"⚠️ فشل الإرسال: {response.text}")
        else:
            print("✅ تم إرسال جزء من الرسالة بنجاح")


def job():
    print(f"🔄 جاري تجميع الترندات... {datetime.now()}")
    message = build_message()
    send_telegram_message(message)
    print("✅ تم الإرسال")


# ============ التشغيل ============
# ملحوظة: الجدولة الأسبوعية دلوقتي بتتم من خارج الكود (عن طريق Render Cron Job)
# فالسكريبت هنا بيشتغل مرة واحدة بس كل ما حد (أو السيرفر) يشغله.

if __name__ == "__main__":
    job()
